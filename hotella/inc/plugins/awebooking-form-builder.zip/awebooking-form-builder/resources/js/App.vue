<template>
  <div id="awebooking-checkout-form-builder">

    <div class="awebooking-draggable">
      <draggable v-model="row.col1" :options="{ group: 'formcontrol', handle: '.my-handle', draggable: '.awebooking-widget', animation: 150}" class="awebooking-drag-area">
        <div v-for="(element, index) in row.col1" class="awebooking-widget">
          <formcontrol :control="element" :index="index" :column="row.col1" v-on:remove-control="removeControl" />
        </div>
      </draggable>

      <draggable v-model="row.col2" :options="{ group: 'formcontrol', handle: '.my-handle', draggable: '.awebooking-widget', animation: 150}" class="awebooking-drag-area">
        <div v-for="(element, index) in row.col2" class="awebooking-widget">
          <formcontrol :control="element" :index="index" :column="row.col2" v-on:remove-control="removeControl" />
        </div>
      </draggable>

      <draggable v-model="row.col3" :options="{ group: 'formcontrol', handle: '.my-handle', draggable: '.awebooking-widget', animation: 150}" class="awebooking-drag-area">
        <div v-for="(element, index) in row.col3" class="awebooking-widget">
          <formcontrol :control="element" :index="index" :column="row.col3" v-on:remove-control="removeControl" />
        </div>
      </draggable>
    </div>

    <p>
      <button class="button" type="button" @click.prevent="addNewControl">&plus;</button>
      <button type="submit" class="button" style="float: right">Save Controls</button>
    </p>

    <input type="hidden" name="_awebooking_controls" :value="JSON.stringify(row)">
  </div>
</template>

<script>
import draggable from 'vuedraggable'
import formcontrol from './FormControl.vue'

const checkout = window._awebookingCheckoutControls;
const defaultControl = _.clone(checkout.defaultControlProps);

export default {
  name: 'app',

  components: {
    draggable,
    formcontrol
  },

  data() {
    return { row: {} }
  },

  created() {
    let _row = { col1: [], col2: [], col3: [] };
    const controls = _.clone(checkout.controls);

    if (typeof checkout.controls.col1 === 'undefined') {
      _row.col1 = controls;
    } else {
      _row = _.extend(_row, controls);
    }

    _row = _.mapObject(_row, function(col, name) {
      return _.map(col, (_control) => {
        return Object.assign({}, defaultControl, _control );
      });
    });

    this.row = _row;
  },

  methods: {
    removeControl(columns, index) {
      if (window.confirm('Are you sure?')) {
        columns.splice(index, 1);
      }
    },

    addNewControl() {
      const clone = _.clone(checkout.defaultControlProps);
      clone._active = true;

      this.row.col1.push(clone);
    }
  }
}
</script>
