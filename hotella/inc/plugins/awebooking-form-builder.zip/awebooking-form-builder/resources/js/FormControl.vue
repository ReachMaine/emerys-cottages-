<template>
  <div class="awebooking-widget-container" :class="{ active: isActive }">

    <div class="awebooking-widget-top">
      <span class="my-handle"></span>

      <div class="awebooking-widget-title ui-sortable-handle">
        <h3 @click="toggleClass">{{ control.name }} <span>{{ control.type }}</span></h3>
      </div>
    </div>

    <div class="awebooking-widget-inside">
      <p>
        <label class="awebooking-buildform-control">
          <span class="awebooking-buildform-label">Type</span>

          <select v-model="control.type">
            <option v-for="(args, type) in supportTypes" :value="type">{{ args.label }}</option>
          </select>
        </label>

        <label class="awebooking-buildform-control">
          <span class="awebooking-buildform-label">Name</span>
          <input type="text" v-model="control.name">
        </label>
      </p>

      <p>
        <label class="awebooking-buildform-control">
          <span class="awebooking-buildform-label">Description</span>
          <textarea v-model="control.desc" style="height: 35px;"></textarea>
        </label>
      </p>

      <p v-show="isSelectable">
        <label class="awebooking-buildform-control">
          <span class="awebooking-buildform-label">Options</span>
          <textarea v-model="control.options"></textarea>
        </label>
      </p>

      <p>
        <label class="awebooking-buildform-control">
          <span class="awebooking-buildform-label">Validate</span>
          <input type="text" v-model="control.validate">
        </label>
      </p>

      <div>
        <a @click="$emit('remove-control', column, index)" class="button abutton-dashicons" v-show="canDelete">
          <span class="screen-reader-text">Delete</span>
          <span class="dashicons dashicons-trash"></span>
        </a>

        <label class="awebooking-buildform-control">
          <!-- <input type="checkbox" v-model="control.required"> Required? -->
        </label>
      </div>
    </div>

  </div>
</template>

<script>
const uniqid = require('uniqid');
const checkout = window._awebookingCheckoutControls;

const defaultControl = _.clone(checkout.defaultControlProps);

export default {
  name: 'form-control',

  props: {
    index: {
      type: Number,
      require: true
    },

    control: {
      type: Object,
      required: true,
      default: defaultControl
    },

    column: {
      type: Array,
      required: true,
    }
  },

  data() {
    return {
      isActive: false,
      supportTypes: checkout.supportTypes
    }
  },

  created() {
    if (! this.control.id) {
      this.control.id = uniqid( 'awebooking-' );
    }

    if (this.control._active) {
      this.isActive = true;
    }
  },

  methods: {
    toggleClass() {
      this.isActive = !this.isActive;
    }
  },

  computed: {
    canDelete() {
      return ! (this.control.hasOwnProperty('_plugable') && false == this.control._plugable);
    },

    isSelectable() {
      const selectable = [ 'radio', 'multicheck', 'select' ];
      return selectable.includes(this.control.type);
    }
  }
}
</script>
