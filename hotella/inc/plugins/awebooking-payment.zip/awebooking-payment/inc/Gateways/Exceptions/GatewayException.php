<?php
namespace AweBooking\Payment\Gateways;

class GatewayException extends RuntimeException {}
