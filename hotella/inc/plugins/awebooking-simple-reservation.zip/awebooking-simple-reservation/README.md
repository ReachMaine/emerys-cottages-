## Unit Test

```
./bin/install-wp-tests.sh test_awebooking root '' localhost latest
```
