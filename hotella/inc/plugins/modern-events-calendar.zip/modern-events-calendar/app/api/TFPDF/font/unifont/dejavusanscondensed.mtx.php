<?php
$name='DejaVuSansCondensed';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 4,
  'FontBBox' => '[-918 -415 1513 1167]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 540.0,
);
$up=-63;
$ut=44;
$ttffile='C:\xampp\htdocs\mec\wp-content\plugins\modern-events-calendar\app\api\TFPDF/font/unifont/DejaVuSansCondensed.ttf';
$originalsize=643852;
$fontkey='dejavu';
?>